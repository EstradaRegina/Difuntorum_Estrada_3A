var game = new Phaser.Game(400, 600, Phaser.CANVAS, 'gameDiv');

var background;
var quit;

var mainState = {

    preload:function(){
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;

    game.load.image("background","img/background.png")
    game.load.image("quit","img/quit.png")

    },

    create:function(){

    game.add.sprite(0,0,"background");

    quit = game.add.button(340,15,"quit",quit);
    quit.scale.x= .3;
    quit.scale.y= .3;

    instructions = game.add.text(90,85,'INSTRUCTIONS',{fill:"black",font:"30px Times New Roman"});
    instructions1 = game.add.text(90,220,'This game is played by 5 players in each.',{fill:"black",font:"18px Times New Roman"});
    instructions2 = game.add.text(50,240,'group As the mechanics of our game, each player',{fill:"black",font:"18px Times New Roman"});
    instructions3 = game.add.text(50,260,'needs to touch one of the player in the other group',{fill:"black",font:"18px Times New Roman"});
    instructions4 = game.add.text(50,280,'so that your score will increase',{fill:"black",font:"18px Times New Roman"});
    instructions5 = game.add.text(50,300,'then when the group gets all the player your lose.',{fill:"black",font:"18px Times New Roman"});


    },


    update: function() {
    },
}

function quit ()
{
     window.location.href="bati1.html";
  {quit.frame=0}  
setTimeout(function(){
    
quit.frame=0;
game._paused=false;
},50);
}

    game.state.add("mainState",mainState);
    game.state.start("mainState");