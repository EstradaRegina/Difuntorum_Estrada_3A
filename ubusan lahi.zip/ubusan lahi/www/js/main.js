var w = 900;
var h = 550;
var bg1,bgblue,btred,btblue,btblue1;
var flipB = true;
var flipR = true;
var scorer=6;
var scoreb=6;
var sctext;
var timetxt;
var teamA;
var teamB;
var bg;
var bgmusic;
var bgfx;
var restart;
var pl;

var game = new Phaser.Game(w,h,Phaser.CANVAS,'game');
var mainStatep1=function(){}