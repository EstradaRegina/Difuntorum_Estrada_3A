var func = function(){
  'use strict';
  return {
     timer:function(initTime,microsec) {
           setInterval(function(){
            initTime--;
            if(initTime>=0){
                timetxt.text="Time: 0." + initTime;
            }
           else
            {
              game.paused=true;
              func.gameover();
            }
           },microsec);

       },
       audio:function (time){
        setInterval(function(){
          bgmusic.play();
        },time)
       },
      createcb:function() {
        for (var x = 0.5; x <= 6 ; x++) {
        btblue = game.add.button(x*120,100, 'btbl', function(btblue) {
          
            if(flipB) { 
            btblue.loadTexture('btrd');
            flipR =true;
             // ?bgfx.play();
             console.log('flip to red');
              scorer++;
              teamA.text='TeamA: '+scorer;
              scoreb--;
             teamB.text='TeamB: '+scoreb;
            }
            else if(flipR){ 
            btblue.loadTexture('btbl');
            flipB = false; 
            // ?bgfx.play(); 
            console.log('flip to blue');
            scorer--;
            teamA.text='TeamA: '+scorer;
            scoreb++;
            teamB.text='TeamB: '+scoreb; 
             }
        });
        btblue.scale.setTo(0.75);
        }
      },
      createcr:function () {
        for (var y = 0.5; y <= 6 ; y++) {
        btred = game.add.button(y*120,250, 'btrd', function(btred) {
         //game.add.tween(btblue).to( { x:-50 }, 2000, Phaser.Easing.Linear.None, true, 2,1000, true).loop(true); 
            if(flipR) { 
            btred.loadTexture('btbl');
            flipB =true;
             // ?bgfx.play();
             console.log('flip to blue');
              scorer--;
              teamA.text='TeamA: '+scorer;
              scoreb++;
             teamB.text='TeamB: '+scoreb;
           }
            else if (flipB){ 
            btred.loadTexture('btrd');
            flipR= false; 
            // ?bgfx.play(); 
            console.log('flip to red');
            scorer++;
            teamA.text='TeamA: '+scorer;
            scoreb--;
            teamA.text='TeamB: '+scoreb; 
            }
             
        });
         // bgfx.play();
        btred.scale.setTo(0.75);
        }
      },
       start:function(){
        func.createcb();
        func.createcr();
        func.timer(60,700);
        pl.visible =false;
      timetxt.visible = true;
      teamA.visible =true;
      teamB.visible=true;
      bg.visible=true;
  },
  gameover:function(){
     restart=game.add.sprite(0,0,'go');
      restart.scale.x=1.5;
     restart.scale.y =1.2;
    game.input.onTap.add(func.restart());
  },
restart:function (){
  window.location.href= window.location.href;
}
     
     }
}();