var mainStatep1={
preload:function (){
		//bg
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.setScreenSize= true;
        game.load.image('btrd','img/kk.png');
        game.load.image('btbl','img/buttonblue.png');
        game.load.image('bg1','img/background.png');
        game.load.image('bgb','img/bgb.png');
        game.load.audio('bgm','audio/audiobg.mp3');
        game.load.audio('bgfx','audio/fx.mp3');
        game.load.image('pl','img/front1.png');
        game.load.image('go','img/restart.png');

       },
create:function (){
        game.physics.startSystem(Phaser.Physics.ARCADE);
         bg = game.add.sprite(0, 0, 'bg1');
         bg.scale.x= 2;
         bg.scale.y= 2;

          pl=game.add.sprite(0,0,'pl');
     pl.scale.x=1.5;
     pl.scale.y =1.2;
        

         bgmusic = game.add.audio('bgm',1,true);
        bgmusic.loop =true;
        bgmusic.play();{}

        // func.audio(7000);
         bgfx = game.add.audio('bgfx');
        // func.fx(1000);

     // sctext=game.add.text(750,0 , 'Score : 0' ,{ fontSize: '40px', fill: '#fff' });
     timetxt= game.add.text(100,0 , 'Time: 0.00',{ fontSize: '40px', fill: 'blue' });
     teamA= game.add.text(650,0 , 'TeamA: 6' ,{ fontSize: '40px', fill: 'blue' });
     teamB = game.add.text(650,50 , 'TeamB: 6' ,{ fontSize: '40px', fill: 'blue' });


 
    
  
  timetxt.visible =false;
  teamA.visible=false;
  teamB.visible=false;
  bg.visible=false;
  game.input.onTap.addOnce(func.start);
},
update:function(){

}
}

game.state.add('main',mainStatep1,true);

